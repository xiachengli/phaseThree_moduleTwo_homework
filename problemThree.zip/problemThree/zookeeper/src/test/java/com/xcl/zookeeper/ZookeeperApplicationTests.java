package com.xcl.zookeeper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZookeeperApplicationTests {

    @Test
    void contextLoads() {
    }

}
