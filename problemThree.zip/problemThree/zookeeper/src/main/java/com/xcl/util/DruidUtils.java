package com.xcl.util;

import com.alibaba.druid.pool.DruidDataSource;
import com.xcl.zookeeper.Zkclient;
import org.I0Itec.zkclient.ZkClient;

public class DruidUtils {

    private static final String PATH = "/databaseConfig";

    private static DruidDataSource druidDataSource;

    public static synchronized void refresh(){
        ZkClient zkClient = Zkclient.getIntance();
        zkClient.setZkSerializer(new MyZkSerializer());
        if (zkClient.exists(PATH)){
            String data = zkClient.readData(PATH);
            String[] datas = data.split(";");
            System.out.println(data);
            if (druidDataSource != null) {
                druidDataSource.close();
            }

            druidDataSource = new DruidDataSource();
            druidDataSource.setDriverClassName(datas[0]);
            druidDataSource.setUrl(datas[1]);
            druidDataSource.setUsername(datas[2]);
            druidDataSource.setPassword(datas[3]);
        }

    }

    public static  DruidDataSource getInstance(){
        return druidDataSource;
    }
}
