package com.xcl.zookeeper;

import com.xcl.util.DruidUtils;
import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.ZkClient;

public class Zkclient {

    private static  ZkClient zkClient = new ZkClient("127.0.0.1:2181");

    static {
        zkClient.subscribeDataChanges("/databaseConfig",new IZkDataListener(){
            @Override
            public void handleDataChange(String s, Object o) throws Exception {
                System.out.println("监听到数据发生变化--------------"+s+":"+o);
                DruidUtils.refresh();
            }
            @Override
            public void handleDataDeleted(String s) throws Exception {
                System.out.println("nothing to do");
            }
        });
    }

    public static ZkClient getIntance(){
        return zkClient;
    }

}
