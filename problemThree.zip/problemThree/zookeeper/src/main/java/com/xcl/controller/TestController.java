package com.xcl.controller;

import com.xcl.util.DruidUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Controller
public class TestController {

    @RequestMapping("test")
    public  String test() throws SQLException {
        Connection connection = DruidUtils.getInstance().getConnection();
        String sql = "select * from t_article";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            System.out.println(resultSet.getString("title"));
        }
        return "index";
    }


}
