package com.xcl;

import com.xcl.util.DruidUtils;
import com.xcl.zookeeper.Zkclient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZookeeperApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZookeeperApplication.class, args);
        //初始化数据库连接池
        DruidUtils.refresh();
    }

}
