package com.lagou.client;

import com.lagou.com.lagou.encode.RpcDecoder;
import com.lagou.com.lagou.encode.RpcEncoder;
import com.lagou.com.lagou.serializer.imp.JSONSerializer;
import com.lagou.handler.UserClientHandler;
import com.lagou.serializer.MyZkSerializer;
import com.lagou.vo.RpcRequest;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.I0Itec.zkclient.ZkClient;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RpcConsumer {
    //线程池
    private static ExecutorService executor =
            Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    //通道连接池
    private static Map<String, UserClientHandler> userClientHandlerMap = new HashMap<>();

    static String basePath = "/provider";
    private ZkClient zkClient;

    public RpcConsumer() {
        init();
    }

    /**
     * 创建一个代理对象
     *
     * @param userServiceClass
     * @param providerParam
     * @return
     */
    public Object createProxy(Class<?> userServiceClass, final String providerParam) {
        return Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(),
                new Class<?>[]{userServiceClass}, new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

                        RpcRequest request = new RpcRequest(providerParam,method.getDeclaringClass().getName(),method.getName(),method.getParameterTypes(),args);
                        UserClientHandler userClientHandler = getHandler();
                        if (userClientHandler == null){
                            return null;
                        }
                        userClientHandler.setParam(request);
                        return executor.submit(userClientHandler).get();
                    }
                });
    }

    //可以从连接池中获取连接，可以实施负载策略
    private UserClientHandler getHandler() {
        //第一元素优先
       return userClientHandlerMap.values().iterator().next();
    }

    //获取Bootstrap
    private static UserClientHandler initClient(String ip, int port) {
        UserClientHandler userClientHandler = new UserClientHandler();
        Bootstrap bootstrap = new Bootstrap();
        NioEventLoopGroup group = new NioEventLoopGroup();
        bootstrap.group(group).channel(NioSocketChannel.class)
                .option(ChannelOption.TCP_NODELAY, true)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel socketChannel) throws Exception {
                        ChannelPipeline pipeline = socketChannel.pipeline();
                        pipeline.addLast(new RpcEncoder(RpcRequest.class, new JSONSerializer()));
                        pipeline.addLast(new RpcDecoder(RpcRequest.class, new JSONSerializer()));
                        pipeline.addLast(userClientHandler);
                    }
                });
        try {
            ChannelFuture channelFuture = bootstrap.connect(ip, port).sync();
            userClientHandler.setChannelFuture(channelFuture);

            return userClientHandler;
        } catch (InterruptedException e) {
            e.printStackTrace();

        }
        return null;
    }

    //获取通道
    private void getChannel(String path, String content) {
        try {
            String[] arr = content.split(":");
            if (arr != null && arr.length >= 2) {
                UserClientHandler u = initClient(arr[0], Integer.parseInt(arr[1]));
                userClientHandlerMap.put(path, u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //关闭通道
    private static void closeChannel(String path) {
        try {

            UserClientHandler userClientHandler = userClientHandlerMap.get(path);
            userClientHandler.getChannelFuture().channel().close();
            userClientHandlerMap.remove(path);
            System.out.println(path + "删除成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //初始化服务
    private void init() {
        //连接zookeeper
        zkClient = new ZkClient("127.0.0.1:2181");
        zkClient.setZkSerializer(new MyZkSerializer());

        //监听节点变更通知
        zkClient.subscribeChildChanges(basePath, (path1, list) -> {
            System.out.println("子节点变更：" + path1 + ",节点数量：" + list.size());
            System.out.println(list);
            //缓存节点数量大于 剩余节点数量，说明有节点删除
            if (userClientHandlerMap.keySet().size() > list.size()) {
                userClientHandlerMap.keySet().forEach(v -> {
                    String s = v.substring(v.lastIndexOf("/") + 1);
                    if (!list.contains(s)) {
                        System.out.println(v + "节点下线，关闭连接");
                        closeChannel(v);
                    }
                });
            } else {
                Thread.sleep(3000);
                list.forEach(s -> {
                    String path = path1 + "/" + s;
                    Set<String> set = userClientHandlerMap.keySet();
                    if (!set.contains(path)) {
                        System.out.println(path + "节点上线，建立连接");
                        Object o = zkClient.readData(path);
                        getChannel(path, o.toString());
                    }
                });
            }
            System.out.println("节点变更，当前连接数量：" + userClientHandlerMap.size());
        });

        //获取所有子节点, 获取节点内容，然后建立客户端到服务端的连接
        List<String> children = zkClient.getChildren(basePath);
        for (String path : children) {
            path = basePath + "/" + path;
            Object o = zkClient.readData(path);
            getChannel(path, o.toString());
        }
        System.out.println("服务启动，当前连接数量：" + userClientHandlerMap.size());
    }

}
