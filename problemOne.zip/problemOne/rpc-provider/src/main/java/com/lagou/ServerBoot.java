package com.lagou;

import com.lagou.service.UserServiceImpl;
import org.apache.zookeeper.KeeperException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

@SpringBootApplication
public class ServerBoot {

    public static void main(String[] args) throws InterruptedException, IOException, KeeperException {
        SpringApplication.run(ServerBoot.class, args);
        //启动服务器
        UserServiceImpl.startServer("127.0.0.1",8998);
    }
}
