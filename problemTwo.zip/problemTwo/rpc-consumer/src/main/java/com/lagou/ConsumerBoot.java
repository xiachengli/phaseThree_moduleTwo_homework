package com.lagou;

import com.lagou.client.RpcConsumer;
import com.lagou.service.IUserService;

public class ConsumerBoot {

    //参数定义
    private static final String PROVIDER_NAME = "UserService#sayHello#";

    public static void main(String[] args) throws InterruptedException {

        //1.创建代理对象
        RpcConsumer rpcConsumer = new RpcConsumer();

        //2.循环给服务器写数据
        while (true){
            IUserService service = (IUserService) rpcConsumer.createProxy(IUserService.class, PROVIDER_NAME);
            String result = service.sayHello("hello~");
            System.out.println(result);
            Thread.sleep(2000);
        }

    }
}
