package com.lagou.service;

public interface IUserService {

    String sayHello(String smg);

}
